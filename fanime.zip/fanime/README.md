# FAnime

Web xem anime (KKPhim, NguonC) và đọc truyện (MangaDEX).

- `index.html`: toàn bộ trang web
- `wrangler.jsonc`, `.assetsignore`: cấu hình để Cloudflare host trang tĩnh
- `mangadex-proxy.js`: code cho Cloudflare Worker proxy MangaDEX (tạo Worker riêng, không đưa vào trang)
